package com.example.billingservice.Model;

    
import java.util.Date;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Billing {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String billNo;
    private Date dateOfAdmission;
    private Date dateOfDischarge;
    private double roomCharges;
    private double doctorFees;
    private double medicalFees;

    // Constructors, getters, and setters...

    public Billing() {
    }

    public Billing(String billNo, Date dateOfAdmission, Date dateOfDischarge, double roomCharges, double doctorFees, double medicalFees) {
        this.billNo = billNo;
        this.dateOfAdmission = dateOfAdmission;
        this.dateOfDischarge = dateOfDischarge;
        this.roomCharges = roomCharges;
        this.doctorFees = doctorFees;
        this.medicalFees = medicalFees;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getBillNo() {
        return billNo;
    }

    public void setBillNo(String billNo) {
        this.billNo = billNo;
    }

    public Date getDateOfAdmission() {
        return dateOfAdmission;
    }

    public void setDateOfAdmission(Date dateOfAdmission) {
        this.dateOfAdmission = dateOfAdmission;
    }

    public Date getDateOfDischarge() {
        return dateOfDischarge;
    }

    public void setDateOfDischarge(Date dateOfDischarge) {
        this.dateOfDischarge = dateOfDischarge;
    }

    public double getRoomCharges() {
        return roomCharges;
    }

    public void setRoomCharges(double roomCharges) {
        this.roomCharges = roomCharges;
    }

    public double getDoctorFees() {
        return doctorFees;
    }

    public void setDoctorFees(double doctorFees) {
        this.doctorFees = doctorFees;
    }

    public double getMedicalFees() {
        return medicalFees;
    }

    public void setMedicalFees(double medicalFees) {
        this.medicalFees = medicalFees;
    }

    @Override
    public String toString() {
        return "Billing [id=" + id + ", billNo=" + billNo + ", dateOfAdmission=" + dateOfAdmission
                + ", dateOfDischarge=" + dateOfDischarge + ", roomCharges=" + roomCharges + ", doctorFees=" + doctorFees
                + ", medicalFees=" + medicalFees + "]";
    }


    

   
}

    


