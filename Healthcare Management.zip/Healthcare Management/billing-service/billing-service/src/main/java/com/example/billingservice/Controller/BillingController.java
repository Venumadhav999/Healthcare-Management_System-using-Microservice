package com.example.billingservice.Controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import com.example.billingservice.Model.Billing;
import com.example.billingservice.Service.BillingService;
import java.util.List;


@RestController
@RequestMapping("/api/billings")
public class BillingController {

    private static final Logger LOGGER = LoggerFactory.getLogger(BillingController.class);

    @Autowired
    private BillingService billingService;

    @PostMapping
    public ResponseEntity<Billing> createBilling(@RequestBody Billing billing) {
        LOGGER.info("Billing create: {}", billing);
        Billing createdBilling = billingService.createBilling(billing);
        return new ResponseEntity<>(createdBilling, HttpStatus.CREATED);
    }

    @GetMapping
    public ResponseEntity<List<Billing>> findAllBillings() {
        LOGGER.info("Finding all billings");
        List<Billing> billings = billingService.getAllBillings();
        return new ResponseEntity<>(billings, HttpStatus.OK);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Billing> findBillingById(@PathVariable Long id) {
        LOGGER.info("Finding billing by ID: {}", id);
        Billing billing = billingService.getBillingById(id);
        if (billing != null) {
            return new ResponseEntity<>(billing, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @PutMapping("/{id}")
    public ResponseEntity<Billing> updateBilling(@PathVariable Long id, @RequestBody Billing billing) {
        LOGGER.info("Updating billing with ID {}: {}", id, billing);
        Billing updatedBilling = billingService.updateBilling(id, billing);
        if (updatedBilling != null) {
            return new ResponseEntity<>(updatedBilling, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteBilling(@PathVariable Long id) {
        LOGGER.info("Deleting billing with ID: {}", id);
        billingService.deleteBilling(id);
        return ResponseEntity.ok("Billing cancelled successfully");
    }

}
