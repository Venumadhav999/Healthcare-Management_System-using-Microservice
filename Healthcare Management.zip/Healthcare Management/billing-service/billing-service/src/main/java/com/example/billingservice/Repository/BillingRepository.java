package com.example.billingservice.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.example.billingservice.Model.*;;

public interface BillingRepository extends JpaRepository<Billing, Long> {

}