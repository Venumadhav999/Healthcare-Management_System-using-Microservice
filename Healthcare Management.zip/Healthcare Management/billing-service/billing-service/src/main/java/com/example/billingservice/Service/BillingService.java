package com.example.billingservice.Service;

import org.springframework.stereotype.Service;

import com.example.billingservice.Model.Billing;
import com.example.billingservice.Repository.BillingRepository;

import java.util.List;

@Service
public class BillingService {

    private final BillingRepository billingRepository;

    public BillingService(BillingRepository billingRepository) {
        this.billingRepository = billingRepository;
    }

    public List<Billing> getAllBillings() {
        return billingRepository.findAll();
    }

    public Billing getBillingById(Long id) {
        return billingRepository.findById(id).orElse(null);
    }

    public Billing createBilling(Billing billing) {
        return billingRepository.save(billing);
    }

    public void deleteBilling(Long id) {
        billingRepository.deleteById(id);
    }

    public Billing updateBilling(Long id, Billing billing) {
        Billing existingBilling = billingRepository.findById(id).orElse(null);
        if (existingBilling != null) {
            existingBilling.setBillNo(billing.getBillNo());
            existingBilling.setDateOfAdmission(billing.getDateOfAdmission());
            existingBilling.setDateOfDischarge(billing.getDateOfDischarge());
            existingBilling.setRoomCharges(billing.getRoomCharges());
            existingBilling.setDoctorFees(billing.getDoctorFees());
            existingBilling.setMedicalFees(billing.getMedicalFees());
            return billingRepository.save(existingBilling);
        }
        return null;
    }
}
