package com.example.doctorservice.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.doctorservice.Model.Doctor;
import com.example.doctorservice.Repository.DoctorRepository;
import java.util.List;
import java.util.Optional;

@Service
public class DoctorService {

    @Autowired
    private DoctorRepository doctorRepository;

    public List<Doctor> getAllDoctors() {
        return doctorRepository.findAll();
    }

    public Optional<Doctor> getDoctorById(Long id) {
        return doctorRepository.findById(id);
    }

    public Doctor createDoctor(Doctor doctor) {
        return doctorRepository.save(doctor);
    }

    public Doctor updateDoctor(Long id, Doctor doctorDetails) {
        Optional<Doctor> doctorOptional = doctorRepository.findById(id);
        if (doctorOptional.isPresent()) {
            Doctor doctor = doctorOptional.get();
            doctor.setName(doctorDetails.getName());
            doctor.setSpecialization(doctorDetails.getSpecialization());
            doctor.setPhoneNumber(doctorDetails.getPhoneNumber());
            doctor.setAvailability(doctorDetails.getAvailability());
            return doctorRepository.save(doctor);
        } else {
            return null;
        }
    }

    public void deleteDoctor(Long id) {
        doctorRepository.deleteById(id);
    }

    public Optional<Doctor> findByUsernameAndPassword(String username, String password) {
        return doctorRepository.findByUsernameAndPassword(username, password);
    }

    public Optional<Doctor> getDoctorByName(String name) {
        return doctorRepository.findByName(name);
    }
}