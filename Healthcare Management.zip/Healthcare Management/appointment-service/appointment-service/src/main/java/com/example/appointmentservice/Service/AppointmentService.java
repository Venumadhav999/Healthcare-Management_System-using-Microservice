package com.example.appointmentservice.Service;

import com.example.appointmentservice.Model.Appointment;
import com.example.appointmentservice.Repository.AppointmentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class AppointmentService {

    @Autowired
    private final AppointmentRepository appointmentRepository;

    public AppointmentService(AppointmentRepository appointmentRepository) {
        this.appointmentRepository = appointmentRepository;
    }

    public List<Appointment> getAllAppointments() {
        return appointmentRepository.findAll();
    }

    public Optional<Appointment> findAppointmentById(Long id) {
        return appointmentRepository.findById(id);
    }

    public Appointment createAppointment(Appointment appointment) {
        return appointmentRepository.save(appointment);
    }

    public Appointment updateAppointment(Long id, Appointment appointmentDetails) {
        return appointmentRepository.findById(id).map(appointment -> {
            appointment.setDoctorId(appointmentDetails.getDoctorId());
            appointment.setAppointmentDateTime(appointmentDetails.getAppointmentDateTime());
            appointment.setStatus(appointmentDetails.getStatus());
            return appointmentRepository.save(appointment);
        }).orElse(null);
    }

    public boolean cancelAppointment(Long id) {
        return appointmentRepository.findById(id).map(appointment -> {
            appointmentRepository.deleteById(id);
            return true;
        }).orElse(false);
    }
}
